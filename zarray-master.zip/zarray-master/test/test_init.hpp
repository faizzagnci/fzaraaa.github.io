#ifndef ZARRAY_TEST_INIT_HPP
#define ZARRAY_TEST_INIT_HPP

namespace xt
{
    void initialize_dispatchers();
}

#endif

